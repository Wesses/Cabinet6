const getNearestDir = () => {
}

export default getNearestDir;
